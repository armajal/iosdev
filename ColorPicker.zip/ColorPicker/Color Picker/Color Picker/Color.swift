//
//  Color.swift
//  Color Picker
//
//  Created by Armaja LaRue-Hill on 12/3/19.
//  Copyright © 2019 Armaja LaRue-Hill. All rights reserved.
//

import Foundation
import UIKit

struct Color{
    
    let name: String
    let uiColor: UIColor
}
